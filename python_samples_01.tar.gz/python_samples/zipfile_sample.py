#! /usr/bin/env python

import os, zipfile

# Create a file named test.txt and write "test" on it
x = open("test.txt","w")
x.write("test")
x.close()

# Zip the test file into test.zip
zipf = zipfile.ZipFile("test.zip", "w")
zipf.writestr("test.txt", open("test.txt", "rb").read())

# Create a folder named test and extract the contents of text.zip into it
os.mkdir("test")
zipf.extractall("test")
