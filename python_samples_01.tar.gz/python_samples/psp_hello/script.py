#! /usr/bin/env python
#-*- coding: ISO-8859-1 -*-

import psp2d

def main():
    scr = psp2d.Screen()
    fnt = psp2d.Font('font.png')
    img = psp2d.Image(480, 272)
    img.clear(psp2d.Color(0, 0, 0))
    fnt.drawText(img, 0, 0, 'Hello world')
    scr.blit(img)
    scr.swap()
main()
