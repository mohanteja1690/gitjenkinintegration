#! /usr/bin/env python

import urllib2

url = raw_input("Enter the url of the file > ")
dl = urllib2.urlopen(url)
dl_file = open("download","w")
dl_file.write(dl.read())
dl_file.close()
