#! /usr/bin/env python
# Run shell commands

import os

os.system("echo Hello World")
