#! /usr/bin/env python
#-*- coding: UTF-8 -*-

import Tkinter
x = Tkinter.Tk(className="Hello")
hello = Tkinter.Message(x, text="Hello World\n" + "\n" + "Hola Mundo")
hello.pack()
x.mainloop()
