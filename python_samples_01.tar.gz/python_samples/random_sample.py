#! /usr/bin/env python
import random

# Select from a list
x = [1,2,3,4,5,6,7,8,9,0]
print random.choice(x)

# Generate random 10 digit number
print int("".join(random.sample("1234567890",10)))

# Generate random 10 character string
print "".join(random.sample("qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890",10))

# Generate number from 0 to 100
print random.randrange(100)
