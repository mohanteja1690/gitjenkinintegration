#! /usr/bin/env python
#-*- coding: UTF-8 -*-

raw_input("Hello World\nHola Mundo")
