#! /usr/bin/env python
# How to tell if script is runned or imported

if __name__ == "__main__":
	print "Runned"
else: print "Imported"
