#! /usr/bin/env python
import Tkinter
from Tkinter import IntVar

def main():

	if checkbutton_variable.get() == 0: print "Checkbutton: not ticked"
	elif checkbutton_variable.get() == 1: print "Checkbutton: ticked"

	print "Entry:", entry.get()

	if radiobutton_var.get() == 0: print "Radiobutton: None selected"
	elif radiobutton_var.get() == 1: print "Radionbutton: Option 1 selected"
	elif radiobutton_var.get() == 2: print "Radionbutton: Option 2 selected"
	elif radiobutton_var.get() == 3: print "Radionbutton: Option 3 selected"

	try: print "Listbox:", listbox.get(listbox.curselection()[0])
	except: print "Listbox: nothing selected"

	print "Spinbox value:", spinbox.get()

main_window = Tkinter.Tk()

checkbutton_variable = IntVar()
checkbutton = Tkinter.Checkbutton(main_window, text="This is a checkbutton", variable=checkbutton_variable)

entry = Tkinter.Entry(main_window)

radiobutton_var = IntVar()
radiobutton1 = Tkinter.Radiobutton(main_window, text="Option 1", variable=radiobutton_var, value=1)
radiobutton2 = Tkinter.Radiobutton(main_window, text="Option 2", variable=radiobutton_var, value=2)
radiobutton3 = Tkinter.Radiobutton(main_window, text="Option 3", variable=radiobutton_var, value=3)

listbox = Tkinter.Listbox(main_window)
list_ = ["Option 1", "Option 2", "Option 3"]
for i in list_:
    listbox.insert(1, i)
#listbox.insert(1, "Option 1")
#listbox.insert(2, "Option 2")
#listbox.insert(3, "Option 3")

spinbox = Tkinter.Spinbox(main_window, from_=0, to=10)

button = Tkinter.Button(main_window, text="This is a button\nClick Me!", command=main)

checkbutton.pack()
entry.pack()
radiobutton1.pack()
radiobutton2.pack()
radiobutton3.pack()
listbox.pack()
spinbox.pack()
button.pack()

main_window.mainloop()
